// 1. Import the Express library
const express = require('express');

// 2. Create an instance of an Express application
const app = express();
const PORT = 3000; // Define a port for our server to listen on

// Some dummy data for our API
const users = [
  { id: 1, name: 'Alice' },
  { id: 2, name: 'Bob' },
  { id: 3, name: 'Charlie' }
];

// 3. Define the endpoints (routes)

// The root endpoint
app.get('/', (req, res) => {
  res.send('Welcome to my API!');
});

// The /users endpoint
app.get('/users', (req, res) => {
  res.json(users); // res.json() automatically sends data as JSON
});

// A dynamic endpoint to get a single user by their ID
app.get('/users/:id', (req, res) => {
  const userId = parseInt(req.params.id); // Get the ID from the URL
  const user = users.find(u => u.id === userId);

  if (user) {
    res.json(user);
  } else {
    res.status(404).send('User not found'); // Send a 404 Not Found status
  }
});

// 4. Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// A simple middleware function to check for an API key
function checkApiKey(req, res, next) {
  const apiKey = req.header('x-api-key'); // Clients must send the key in a header
  if (apiKey === 'my-secret-key-123') {
    next(); // The key is valid, proceed to the next function
  } else {
    res.status(401).send('Unauthorized: Invalid API Key');
  }
}

// Apply the middleware to a specific route
app.get('/users', checkApiKey, (req, res) => {
    res.json(users);
});

const cors = require('cors');
app.use(cors({ origin: 'https://my-trusted-website.com' })); // Only allow requests from this domain

const rateLimit = require('express-rate-limit');
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // Limit each IP to 100 requests per window
});
app.use(limiter); // Apply to all requests
