// Define the API endpoint for users
const API_ENDPOINT = 'https://jsonplaceholder.typicode.com/users';

// Select the <ul> element where we will display the names
const userListElement = document.querySelector('#user-list');

// Create an async function to fetch and display the data
async function fetchUsers() {
  try {
    // 1. Make a GET request to the API endpoint
    const response = await fetch(API_ENDPOINT);

    // Check if the response was successful
    if (!response.ok) {
      throw new Error(`HTTP Error! Status: ${response.status}`);
    }

    // 2. Convert the response body to JSON
    const users = await response.json();

    // Clear the "Loading..." text
    userListElement.innerHTML = '';

    // 3. Loop through the users and display their names
    users.forEach(user => {
      const listItem = document.createElement('li');
      listItem.textContent = user.name;
      userListElement.append(listItem);
    });

  } catch (error) {
    // Handle any errors that occurred during the fetch
    console.error('Could not fetch users:', error);
    userListElement.innerHTML = '<li>Failed to load users.</li>';
  }
}

// Call the function to run it when the page loads
fetchUsers();